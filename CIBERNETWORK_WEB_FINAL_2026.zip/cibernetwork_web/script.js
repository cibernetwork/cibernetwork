const phone = '527733320623';
const waUrl = (message) => `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;

document.querySelectorAll('.wa-link').forEach(link => {
  link.href = waUrl(link.dataset.msg || 'Hola, quiero información de CIBERNETWORK.');
  link.target = '_blank';
  link.rel = 'noopener';
});

const form = document.getElementById('quote-form');
form?.addEventListener('submit', (event) => {
  event.preventDefault();
  const name = document.getElementById('name').value.trim();
  const location = document.getElementById('location').value.trim();
  const service = document.getElementById('service').value;
  const details = document.getElementById('details').value.trim();
  const message = `Hola, soy ${name}.\nComunidad: ${location}.\nServicio: ${service}.\nDetalles: ${details || 'Solicito información y cotización.'}`;
  window.open(waUrl(message), '_blank', 'noopener');
});

const menuButton = document.querySelector('.menu-btn');
menuButton?.addEventListener('click', (event) => {
  const nav = document.querySelector('.nav');
  nav.classList.toggle('open');
  event.currentTarget.setAttribute('aria-expanded', nav.classList.contains('open'));
});
document.querySelectorAll('.nav a').forEach(a => a.addEventListener('click', () => document.querySelector('.nav').classList.remove('open')));
document.getElementById('year').textContent = new Date().getFullYear();

const observer = new IntersectionObserver(entries => entries.forEach(entry => {
  if (entry.isIntersecting) entry.target.classList.add('visible');
}), { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

const modal = document.getElementById('image-modal');
const modalImage = document.getElementById('modal-image');
document.querySelectorAll('.gallery-item').forEach(item => item.addEventListener('click', () => {
  modalImage.src = item.dataset.full;
  modal.showModal();
}));
document.getElementById('modal-close').addEventListener('click', () => modal.close());
modal.addEventListener('click', (e) => { if (e.target === modal) modal.close(); });
