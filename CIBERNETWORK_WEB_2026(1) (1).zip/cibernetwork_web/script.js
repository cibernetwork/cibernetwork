const phone = '527733320623';
const waUrl = (message) => `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;

document.querySelectorAll('.wa-link').forEach(link => {
  link.href = waUrl(link.dataset.msg || 'Hola, quiero información de CIBERNETWORK.');
  link.target = '_blank';
  link.rel = 'noopener';
});

document.getElementById('quote-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const name = document.getElementById('name').value.trim();
  const location = document.getElementById('location').value.trim();
  const service = document.getElementById('service').value;
  const details = document.getElementById('details').value.trim();
  const message = `Hola, soy ${name}.\nComunidad: ${location}.\nServicio: ${service}.\nDetalles: ${details || 'Solicito información y cotización.'}`;
  window.open(waUrl(message), '_blank', 'noopener');
});

document.querySelector('.menu-btn').addEventListener('click', (event) => {
  const nav = document.querySelector('.nav');
  nav.classList.toggle('open');
  event.currentTarget.setAttribute('aria-expanded', nav.classList.contains('open'));
});

document.querySelectorAll('.nav a').forEach(a => a.addEventListener('click', () => document.querySelector('.nav').classList.remove('open')));
document.getElementById('year').textContent = new Date().getFullYear();
